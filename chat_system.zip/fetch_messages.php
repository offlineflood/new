
<?php
include 'db.php';

$receiver_id = $_GET['receiver_id'];

$stmt = $conn->prepare("SELECT * FROM messages WHERE receiver_id = :receiver_id ORDER BY timestamp ASC");
$stmt->execute(['receiver_id' => $receiver_id]);

$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($messages);
?>
