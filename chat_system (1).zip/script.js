
const chatMessages = document.getElementById('chatMessages');
const chatForm = document.getElementById('chatForm');
const messageInput = document.getElementById('messageInput');
const receiverId = 1;

function fetchMessages() {
    fetch(`fetch_messages.php?receiver_id=${receiverId}`)
        .then(response => response.json())
        .then(data => {
            chatMessages.innerHTML = '';
            data.forEach(msg => {
                const div = document.createElement('div');
                div.classList.add('message', msg.sender_id == 1 ? 'self' : 'other');
                div.innerHTML = `
                    <div class="username">${msg.username}</div>
                    <div>${msg.message}</div>
                    <div class="timestamp">${new Date(msg.timestamp).toLocaleTimeString()}</div>
                `;
                chatMessages.appendChild(div);
            });
        });
}

chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const message = messageInput.value;

    fetch('send_message.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `sender_id=1&receiver_id=${receiverId}&message=${message}`
    }).then(() => {
        messageInput.value = '';
        fetchMessages();
    });
});

setInterval(fetchMessages, 2000);
